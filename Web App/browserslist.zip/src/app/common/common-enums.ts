export enum UserType {
    Admin = 1,
    BookSeller = 2
}

export enum DialogType {
    Confirmation = 1,
    Alert = 2
}
