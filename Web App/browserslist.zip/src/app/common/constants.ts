export const Constants = {
    DelimiterOfAddress: '/\\@$~^'
}