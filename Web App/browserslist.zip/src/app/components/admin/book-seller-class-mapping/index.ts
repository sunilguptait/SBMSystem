export * from './book-seller-school-mapping-add/book-seller-school-mapping-add.component'
export * from './book-seller-school-mapping-list/book-seller-school-mapping-list.component'