export * from './school-add/school-add.component'
export * from './school-list/school-list.component'