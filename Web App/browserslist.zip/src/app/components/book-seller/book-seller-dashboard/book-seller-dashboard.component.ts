import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-seller-dashboard',
  templateUrl: './book-seller-dashboard.component.html',
  styleUrls: ['./book-seller-dashboard.component.scss']
})
export class BookSellerDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
