import { Component, OnInit } from '@angular/core';
import { CommonService, SessionService } from '../../../../services';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonAPIsService } from '../../../../services/common-apis.service';
import { SessionKeys } from '../../../../common/session-keys';
import { ConstantPool } from '@angular/compiler';
import { BookService } from '../../../../services/book.service';
import { PublisherService } from '../../../../services/publisher.service';

@Component({
  selector: 'app-book-add',
  templateUrl: './book-add.component.html',
  styleUrls: ['./book-add.component.scss']
})
export class BookAddComponent implements OnInit {

  bookForm: FormGroup;
  submitted = false;
  loading = false;
  hide = false;
  publisherList: any = [];
  bookTypeList: any = [];
  bookId: number = 0;
  bookDetails: any = {};
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private sessionKeys: SessionKeys,
    private commonService: CommonService,
    private sessionService: SessionService,
    private activeRoute: ActivatedRoute,
    private bookService: BookService,
    private commonAPIsService: CommonAPIsService,
    private publisherService: PublisherService,

  ) { }

  ngOnInit() {
    this.getBookTypes();
    this.getPublishers();
    this.initializeForm();
    this.activeRoute.params.subscribe(params => {
      if (params['id']) {
        this.bookId = params['id'];
        this.getbookDetails();
      }
    })
  }

  initializeForm() {
    this.bookForm = this.formBuilder.group({
      Book_Id: [0],
      Book_Name: ['', Validators.required],
      Book_ShortName: ['', Validators.required],
      Book_PublisherId: ['', Validators.required],
      Book_Price: ['', Validators.required],
      Book_TypeId: ['', Validators.required],
    })
  }

  getbookDetails() {
    this.bookDetails = this.sessionService.getSessionAsJSON(this.sessionKeys.Keys.Book.Details);
    if (this.bookDetails) {
      for (var prop in this.bookDetails) {
        if (Object.prototype.hasOwnProperty.call(this.bookDetails, prop)) {
          const formControl = this.bookForm.get(prop);
          if (formControl) {
            formControl.setValue(this.bookDetails[prop]);
          }
        }
      }
    }
  }

  getBookTypes() {
    this.commonAPIsService.getBookTypes()
      .subscribe(
        response => {
          if (!this.commonService.validateAPIResponse(response)) {
            return; // show error message and return in case of any error from API
          }
          this.bookTypeList = response.Data;
        })
  }

  getPublishers() {
    this.publisherService.getListForDropdown()
      .subscribe(
        response => {
          if (!this.commonService.validateAPIResponse(response)) {
            return; // show error message and return in case of any error from API
          }
          this.publisherList = response.Data;
        })
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.bookForm.controls[controlName].hasError(errorName);
  }

  onSubmit(formData) {
    this.submitted = true;
    if (this.bookForm.invalid) {
      return;
    }
    this.commonService.showSpinner();
    this.bookService.save(formData)
      .subscribe(
        response => {
          if (!this.commonService.validateAPIResponse(response)) {
            return; // show error message and return in case of any error from API
          }
          this.commonService.showSuccessMessage(response.Data);
          this.router.navigate(["/book-seller/book"]);
        })
  }

  onCancel() {
    this.router.navigate(["/book-seller/book"]);
  }

  onBack() {
    this.router.navigate(["/book-seller/book"]);
  }
}
