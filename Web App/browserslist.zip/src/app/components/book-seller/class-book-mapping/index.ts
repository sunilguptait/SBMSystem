export * from './class-book-mapping-add/class-book-mapping-add.component'
export * from './class-book-mapping-list/class-book-mapping-list.component'  