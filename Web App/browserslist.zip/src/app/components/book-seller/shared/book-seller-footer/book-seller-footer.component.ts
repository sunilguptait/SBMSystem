import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-seller-footer',
  templateUrl: './book-seller-footer.component.html',
  styleUrls: ['./book-seller-footer.component.scss']
})
export class BookSellerFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
