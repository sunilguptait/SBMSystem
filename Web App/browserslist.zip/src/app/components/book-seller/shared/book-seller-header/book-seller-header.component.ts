import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-seller-header',
  templateUrl: './book-seller-header.component.html',
  styleUrls: ['./book-seller-header.component.scss']
})
export class BookSellerHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
