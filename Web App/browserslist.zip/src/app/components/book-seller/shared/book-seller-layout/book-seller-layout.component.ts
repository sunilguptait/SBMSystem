import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-seller-layout',
  templateUrl: './book-seller-layout.component.html',
  styleUrls: ['./book-seller-layout.component.scss']
})
export class BookSellerLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
