import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-seller-sidebar',
  templateUrl: './book-seller-sidebar.component.html',
  styleUrls: ['./book-seller-sidebar.component.scss']
})
export class BookSellerSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
