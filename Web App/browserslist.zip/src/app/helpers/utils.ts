export class Utils {
    // public static Genders:string[]=["Male","Female"]
   
    // public static getCurrentUser() {
    //     var user = localStorage.getItem('currentUser');
    //     return JSON.parse(user);
    // }
    // static doSomething(val: string) { return val; }
    // static doSomethingElse(val: string) { return val; }
}